# Advanced Sentiment Analysis (Hugging Face Transformers)

Author: Yogesh

Overview
This project demonstrates an Advanced Sentiment Analysis pipeline using Hugging Face Transformers.
The notebook uses the pipeline('sentiment-analysis') helper and runs inference on sample text data (reviews.csv).

Files
- sentiment_advanced_yogesh.ipynb - Jupyter/Colab notebook with step-by-step code.
- reviews.csv - Sample dataset (text, label).
- requirements.txt - Python dependencies.
- .gitignore - ignores typical Python artifacts.
- run_in_colab.txt - quick instructions to open in Google Colab.

How to run (Google Colab recommended)
1. Open sentiment_advanced_yogesh.ipynb in Google Colab (https://colab.research.google.com).
2. If needed, run: !pip install -r requirements.txt
3. Run all cells. The notebook loads reviews.csv, runs the Hugging Face sentiment pipeline, and saves predictions to predictions.csv.

Notes
- Colab often has PyTorch installed; the notebook will install transformers and pandas if missing.
- Replace reviews.csv with your dataset (CSV with a 'text' column).

Made with love by Yogesh
